package eu.darkcube.minigame.woolbattle.listener.lobby;

import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerLoginEvent.Result;

import eu.darkcube.minigame.woolbattle.Main;
import eu.darkcube.minigame.woolbattle.listener.Listener;

public class ListenerPlayerLogin extends Listener<PlayerLoginEvent> {
	@Override
	@EventHandler
	public void handle(PlayerLoginEvent e) {
		if(Main.getInstance().getMaxPlayers() <= Main.getInstance().getUserWrapper().getUsers().size()) {
			e.disallow(Result.KICK_FULL, e.getKickMessage());
		}
	}
}