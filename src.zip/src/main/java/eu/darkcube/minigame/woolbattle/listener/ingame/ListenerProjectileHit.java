package eu.darkcube.minigame.woolbattle.listener.ingame;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftArrow;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.ProjectileHitEvent;

import eu.darkcube.minigame.woolbattle.game.Ingame;
import eu.darkcube.minigame.woolbattle.listener.Listener;
import eu.darkcube.minigame.woolbattle.util.scheduler.Scheduler;
import net.minecraft.server.v1_8_R3.EntityArrow;
import net.minecraft.server.v1_8_R3.NBTTagCompound;

public class ListenerProjectileHit extends Listener<ProjectileHitEvent> {

	@Override
	@EventHandler
	public void handle(ProjectileHitEvent e) {
		if (e.getEntityType() == EntityType.ARROW) {
			new Scheduler() {
				@Override
				public void run() {
					EntityArrow arrow = ((CraftArrow) e.getEntity()).getHandle();
					NBTTagCompound nbt = new NBTTagCompound();
					arrow.b(nbt);
					double x = nbt.getShort("xTile");
					double y = nbt.getShort("yTile");
					double z = nbt.getShort("zTile");
					if (y != -1) {
						Block b = e.getEntity().getWorld().getBlockAt((int) x, (int) y, (int) z);
						if (b.getType() == Material.WOOL) {
							Ingame.setBlockDamage(b, Ingame.getBlockDamage(b) + 1);
						}
					}
					arrow.die();
				}
			}.runTaskLater(1);
		}
	}
}