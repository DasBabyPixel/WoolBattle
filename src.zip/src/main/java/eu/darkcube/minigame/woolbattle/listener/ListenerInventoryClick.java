package eu.darkcube.minigame.woolbattle.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;

import eu.darkcube.minigame.woolbattle.Main;
import eu.darkcube.minigame.woolbattle.event.EventInteract;

public class ListenerInventoryClick extends Listener<InventoryClickEvent> {

	@Override
	@EventHandler
	public void handle(InventoryClickEvent e) {
		if(Main.getInstance().getLobby().isEnabled() && e.getHotbarButton() != -1) {
			e.setCancelled(true);
			return;
		}
		if (e.getWhoClicked() instanceof Player) {
			if (e.getRawSlot() != -1 && e.getRawSlot() != -999) {
				EventInteract pe = new EventInteract((Player) e.getWhoClicked(), e.getCurrentItem(),
						e.getClickedInventory(), e.getClick());
				Bukkit.getPluginManager().callEvent(pe);
				e.setCancelled(pe.isCancelled());
				e.setCurrentItem(pe.getItem());
			} else {
				e.setCancelled(true);
			}
		}
	}
}