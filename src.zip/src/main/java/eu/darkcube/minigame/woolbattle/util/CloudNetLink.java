package eu.darkcube.minigame.woolbattle.util;

import de.dytanic.cloudnet.ext.bridge.BridgeHelper;
import de.dytanic.cloudnet.ext.bridge.bukkit.BukkitCloudNetHelper;
import de.dytanic.cloudnet.wrapper.Wrapper;
import eu.darkcube.minigame.woolbattle.Main;
import eu.darkcube.system.GameState;

public class CloudNetLink {

	private static boolean isCloudnet;

	static {
		try {
			Class.forName("de.dytanic.cloudnet.wrapper.Wrapper");
			isCloudnet = true;
		} catch (Exception ex) {
			isCloudnet = false;
		}
	}

	public static void update() {
		if (isCloudnet) {
			GameState current = GameState.UNKNOWN;
			if (Main.getInstance().getLobby().isEnabled()) {
				current = GameState.LOBBY;
			} else if (Main.getInstance().getIngame().isEnabled()) {
				current = GameState.INGAME;
			} else if (Main.getInstance().getEndgame().isEnabled()) {
				current = GameState.STOPPING;
			}
			BukkitCloudNetHelper.setState(current.name());
			BukkitCloudNetHelper.setApiMotd("§a" + Main.getInstance().getMap().getName() + " §7("
					+ Wrapper.getInstance().getCurrentServiceInfoSnapshot().getServiceId().getTaskName()
							.substring("woolbattle".length())
					+ ")");
			BridgeHelper.updateServiceInfo();
		}
	}
}