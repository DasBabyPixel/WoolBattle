package eu.darkcube.minigame.woolbattle.translation;

import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public enum Language {

	ENGLISH(Locale.ENGLISH), GERMAN(Locale.GERMAN),

	;

	private final Locale locale;
	private ResourceBundle bundle;

	Language(Locale locale) {
		this.locale = locale;
		try {
			this.bundle = ResourceBundle.getBundle("messages", this.locale);
		} catch (MissingResourceException ex) {
			System.out.println(ex.getMessage());
			this.bundle = null;
		}
	}

	public ResourceBundle getBundle() {
		return this.bundle;
	}

	public Locale getLocale() {
		return locale;
	}
}
