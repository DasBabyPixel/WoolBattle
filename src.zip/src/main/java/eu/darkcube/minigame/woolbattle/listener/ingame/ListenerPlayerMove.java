package eu.darkcube.minigame.woolbattle.listener.ingame;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerMoveEvent;

import eu.darkcube.minigame.woolbattle.listener.Listener;

public class ListenerPlayerMove extends Listener<PlayerMoveEvent> {

	public Map<Player, Integer> ghostBlockFixCount = new HashMap<>();

	@SuppressWarnings("deprecation")
	@Override
	@EventHandler
	public void handle(PlayerMoveEvent e) {
		double x = e.getTo().getX();
		double z = e.getTo().getZ();
		double offsetX = x > 0 ? 1 - (x - (long) x) : 0 - (x - (long) x);
		double offsetZ = z > 0 ? 1 - (z - (long) z) : 0 - (z - (long) z);
		Player p = e.getPlayer();
		Location to = e.getTo();
		Collection<Location> blocksToCheck = new HashSet<>();
//		Y down
		if (to.getBlock().getType() != Material.AIR && (to.getY() % 1.0 < 1.0 && to.getY() % 1.0 > .5)) {
			if (ghostBlockFixCount.get(p) == null)
				ghostBlockFixCount.put(p, 1);
			else if (ghostBlockFixCount.get(p) > 5) {
				ghostBlockFixCount.remove(p);
				p.teleport(p.getLocation().add(0, .3, 0));
			} else {
				ghostBlockFixCount.put(p, ghostBlockFixCount.get(p) + 1);
			}
			blocksToCheck.add(to.clone());
		}

//		Y up
		Location t = to.clone();
		t.setY(t.getY() + 1.5800000131130201);
		if (t.getBlock().getType() != Material.AIR) {
			blocksToCheck.add(t);
		}
		int additionX = 0;
//		X positive (else X negative)
		if (offsetX < .3) {
			additionX = 1;
		} else if (offsetX > .7) {
			additionX = -1;
		}

		if (additionX != 0) {
			t = to.clone();
			t.setX(t.getBlockX() + additionX);
			blocksToCheck.add(t.clone());
			blocksToCheck.add(t.add(0, 1, 0));
		}

		int additionZ = 0;
//		Z positive (else Z negative)
		if (offsetZ < .3) {
			additionZ = 1;
		} else if (offsetZ > .7) {
			additionZ = -1;
		}

		if (additionZ != 0) {
			t = to.clone();
			t.setZ(t.getBlockZ() + additionZ);
			if (additionX != 0) {
				blocksToCheck.add(t.clone().add(additionX, 0, 0));
				blocksToCheck.add(t.clone().add(additionX, 1, 0));
			}
			blocksToCheck.add(t.clone());
			blocksToCheck.add(t.add(0, 1, 0));
		}
		Collection<Block> packets = new ArrayList<>();
		for (Location loc : blocksToCheck) {
			if (loc.getBlock().getType() != Material.AIR) {
				packets.add(loc.getBlock());
			}
		}
		for (Block b : packets) {
			p.sendBlockChange(b.getLocation(), b.getType(), b.getData());
		}

	}

}
