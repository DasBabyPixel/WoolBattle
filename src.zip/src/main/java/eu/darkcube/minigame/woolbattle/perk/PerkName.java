package eu.darkcube.minigame.woolbattle.perk;

public class PerkName {

	public static final PerkName CAPSULE = new PerkName("CAPSULE");
	public static final PerkName SWITCHER = new PerkName("SWITCHER");
	public static final PerkName LINE_BUILDER = new PerkName("LINE_BUILDER");
	public static final PerkName WOOL_BOMB = new PerkName("WOOL_BOMB");
	public static final PerkName RONJAS_TOILET_SPLASH = new PerkName("RONJAS_TOILET_SPLASH");
			
	public static final PerkName DOUBLE_WOOL = new PerkName("DOUBLE_WOOL");
	public static final PerkName BACKPACK = new PerkName("BACKPACK");
	public static final PerkName ROCKETJUMP = new PerkName("ROCKETJUMP");
	public static final PerkName ARROW_RAIN = new PerkName("ARROW_RAIN");
	public static final PerkName BLINK = new PerkName("BLINK");

	private final String name;

	public PerkName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public PerkType toType() {
		return PerkType.valueOf(this);
	}

	@Override
	public boolean equals(Object o) {
		return (o instanceof PerkName && ((PerkName) o).getName().equals(getName()))
				|| o != null && o.toString().equals(getName());
	}

	@Override
	public String toString() {
		return getName();
	}
}