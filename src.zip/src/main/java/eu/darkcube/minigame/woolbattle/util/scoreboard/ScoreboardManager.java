package eu.darkcube.minigame.woolbattle.util.scoreboard;

public class ScoreboardManager {

	public static Scoreboard createScoreboard() {
		return new Scoreboard();
	}

}
