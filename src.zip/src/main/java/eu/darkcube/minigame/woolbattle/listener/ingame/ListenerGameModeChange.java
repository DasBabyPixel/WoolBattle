package eu.darkcube.minigame.woolbattle.listener.ingame;

import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerGameModeChangeEvent;

import eu.darkcube.minigame.woolbattle.Main;
import eu.darkcube.minigame.woolbattle.listener.Listener;

public class ListenerGameModeChange extends Listener<PlayerGameModeChangeEvent> {

	@Override
	@EventHandler
	public void handle(PlayerGameModeChangeEvent e) {
		Main.getInstance().getIngame().listenerDoubleJump.refresh(e.getPlayer());
	}
}