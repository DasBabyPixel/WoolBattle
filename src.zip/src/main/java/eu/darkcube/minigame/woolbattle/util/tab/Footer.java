package eu.darkcube.minigame.woolbattle.util.tab;

public class Footer {

	private String message;
	
	public Footer(String message) {
		this.message = message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}
	
}
