package eu.darkcube.minigame.woolbattle.util;

public enum InventoryId {

	PERKS, TEAMS, GADGETS, VOTING, PERKS_1, PERKS_2, PERKS_3, VOTING_EP_GLITCH, VOTING_MAP, COMPASS_TELEPORT,
	
}
