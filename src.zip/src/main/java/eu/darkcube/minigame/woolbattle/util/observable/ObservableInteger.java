package eu.darkcube.minigame.woolbattle.util.observable;

public interface ObservableInteger extends ObservableObject<Integer> {
	
}
