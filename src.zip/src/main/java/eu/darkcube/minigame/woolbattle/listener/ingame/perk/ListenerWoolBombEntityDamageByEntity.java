package eu.darkcube.minigame.woolbattle.listener.ingame.perk;

import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.util.Vector;

import eu.darkcube.minigame.woolbattle.Main;
import eu.darkcube.minigame.woolbattle.listener.Listener;
import eu.darkcube.minigame.woolbattle.perk.PerkType;
import eu.darkcube.minigame.woolbattle.user.User;

public class ListenerWoolBombEntityDamageByEntity extends Listener<EntityDamageByEntityEvent> {

	@Override
	@EventHandler
	public void handle(EntityDamageByEntityEvent e) {
		if (e.getEntityType() != EntityType.PLAYER) {
			return;
		}
		Player p = (Player) e.getEntity();
		User user = Main.getInstance().getUserWrapper().getUser(p.getUniqueId());
		if (e.getDamager().getType() == EntityType.PRIMED_TNT) {
			TNTPrimed tnt = (TNTPrimed) e.getDamager();
			if (!(tnt.getSource() instanceof Player)) {
				return;
			}
			Player a = (Player) tnt.getSource();
			User attacker = Main.getInstance().getUserWrapper().getUser(a.getUniqueId());
			e.setCancelled(true);
			double x = p.getLocation().getX() - tnt.getLocation().getX();
			double y = p.getLocation().getY() - tnt.getLocation().getY() + .3;
			double z = p.getLocation().getZ() - tnt.getLocation().getZ();
			x = Math.max(Math.min(x, 3), -3);
			y = Math.max(Math.min(y, 3), -0) + .5;
			z = Math.max(Math.min(z, 3), -3);
			p.setVelocity(new Vector(x, y, z)
					.multiply(calc(tnt.getLocation().distance(p.getLocation()), tnt.getYield() + 1)));

			if (user.getTeam() != attacker.getTeam() && !attacker.isTrollMode()) {
				user.setLastHit(attacker);
				user.setTicksAfterLastHit(0);
			}
		} else if (e.getDamager().getType() == EntityType.SNOWBALL) {
			Snowball bomb = (Snowball) e.getDamager();
			if (bomb.getMetadata("perk").size() != 0
					&& bomb.getMetadata("perk").get(0).asString().equals(PerkType.WOOL_BOMB.getPerkName().getName())) {
				e.setCancelled(true);
			}
		}
	}

	private static double calc(double dist, double rad) {
//		return rad - dist <= 0 ? 0 : dist == 0 ? 1 : Math.pow(Math.pow(1 - dist / 1.3 / rad, 3), .6);
		return rad - dist <= 0 ? 0 : dist == 0 ? 1 : Math.pow(1 - dist / 1.4 / rad, .7);
	}
}