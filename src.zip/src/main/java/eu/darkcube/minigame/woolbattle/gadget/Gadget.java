package eu.darkcube.minigame.woolbattle.gadget;

public enum Gadget {

	HOOK_ARROW
	
}
