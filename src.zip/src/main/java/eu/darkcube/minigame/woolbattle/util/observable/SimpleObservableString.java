package eu.darkcube.minigame.woolbattle.util.observable;

public abstract class SimpleObservableString extends SimpleObservableObject<String> implements ObservableString {

}
