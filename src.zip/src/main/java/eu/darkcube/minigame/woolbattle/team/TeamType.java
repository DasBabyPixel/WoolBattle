package eu.darkcube.minigame.woolbattle.team;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.configuration.file.YamlConfiguration;

import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import eu.darkcube.minigame.woolbattle.Main;
import eu.darkcube.minigame.woolbattle.util.Arrays;
import eu.darkcube.minigame.woolbattle.util.DontSerialize;

public class TeamType implements Comparable<TeamType> {

	private static final Collection<TeamType> TYPES = new HashSet<>();
	public static TeamType SPECTATOR;

	private final String invisibleTag;
	private final String scoreboardTag;
	private final String displayNameKey;
	private boolean enabled;
	private byte woolcolor;
	private char namecolor;
	private int maxPlayers;
	private final int weight;
	@DontSerialize
	private int index;

	public TeamType(String displayNameKey, int weight, byte woolcolor, ChatColor namecolor, boolean enabled,
			int maxPlayers) {
		this.displayNameKey = displayNameKey;
		this.woolcolor = woolcolor;
		this.namecolor = namecolor.getChar();
		this.maxPlayers = maxPlayers;
		this.enabled = enabled;
		this.weight = weight;
		this.index = index(true);
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < this.index; i++) {
			builder.append(ChatColor.DARK_BLUE.toString());
		}
		builder.append(ChatColor.DARK_RED.toString());
		this.scoreboardTag = this.weight + "I" + index;
		this.invisibleTag = builder.toString();
		TYPES.add(this);
	}

	public void save() {
		TYPES.add(this);
		YamlConfiguration cfg = Main.getInstance().getConfig("teams");
		List<String> teams = cfg.getStringList("teams");
		teams.add(serialize());
		cfg.set("teams", teams);
		Main.getInstance().saveConfig(cfg);
	}

	public boolean isDeleted() {
		return !Main.getInstance().getConfig("teams").getStringList("teams").contains(serialize());
	}

	public void delete() {
		YamlConfiguration cfg = Main.getInstance().getConfig("teams");
		List<String> teams = cfg.getStringList("teams");
		teams.remove(serialize());
		cfg.set("teams", teams);
		TYPES.remove(this);
		Main.getInstance().saveConfig(cfg);
	}

	private int index(boolean flag) {
		if (flag)
			this.index = 0;
		for (TeamType type : TYPES) {
			if (type.index == index) {
				index++;
				return index(false);
			}
		}
		return this.index;
	}

	public byte getWoolColor() {
		return woolcolor;
	}

	public String getDisplayNameKey() {
		return displayNameKey;
	}

	public int getIndex() {
		return index;
	}

	public void setEnabled(boolean enabled) {
		delete();
		this.enabled = enabled;
		save();
	}

	public void setMaxPlayers(int maxPlayers) {
		delete();
		this.maxPlayers = maxPlayers;
		save();
	}

	public void setNameColor(ChatColor namecolor) {
		delete();
		this.namecolor = namecolor.getChar();
		save();
	}

	@SuppressWarnings("deprecation")
	public void setWoolColor(DyeColor woolcolor) {
		delete();
		this.woolcolor = woolcolor.getData();
		save();
	}

	public String getInvisibleTag() {
		return invisibleTag;
	}

	public String getIngameScoreboardTag() {
		return "ig" + getWeight();
	}

	public boolean isEnabled() {
		return enabled;
	}

	public int getMaxPlayers() {
		return maxPlayers;
	}

	public char getNameColor() {
		return namecolor;
	}

	public String getScoreboardTag() {
		return scoreboardTag;
	}

	public int getWeight() {
		return weight;
	}

	@Override
	public String toString() {
		return getDisplayNameKey();
	}

	public final String serialize() {
		return new GsonBuilder().setExclusionStrategies(new ExclusionStrategy() {
			@Override
			public boolean shouldSkipField(FieldAttributes var1) {
				return var1.getAnnotation(DontSerialize.class) != null;
			}

			@Override
			public boolean shouldSkipClass(Class<?> var1) {
				return false;
			}
		}).create().toJson(this);
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof TeamType)) {
			return false;
		}
		TeamType o = (TeamType) obj;
		if (o.enabled == enabled && o.displayNameKey.equals(displayNameKey) && o.index == index
				&& o.invisibleTag.equals(invisibleTag) && o.maxPlayers == maxPlayers && o.namecolor == namecolor
				&& o.scoreboardTag.equals(scoreboardTag) && o.weight == weight && o.woolcolor == woolcolor) {
			return true;
		}
		return false;
	}

	public static final TeamType byDisplayNameKey(String displayNameKey) {
		for (TeamType type : TYPES) {
			if (type.displayNameKey.equals(displayNameKey)) {
				return type;
			}
		}
		return null;
	}

	public static final TeamType deserialize(String json) {
		for (TeamType type : TYPES) {
			if (type.serialize().equals(json)) {
				return type;
			}
		}
		TeamType type = new Gson().fromJson(json, TeamType.class);
		type.index(true);
		TYPES.add(type);
		return type;
	}

	public static final TeamType[] validValues() {
		Collection<TeamType> types = Arrays.asList(values());
		types = types.stream().filter(t -> t.isEnabled()).collect(Collectors.toSet());
		return types.toArray(new TeamType[0]);
	}

	public static final TeamType[] values() {
		return TYPES.toArray(new TeamType[0]);
	}

	@Override
	public int compareTo(TeamType o) {
		return -((Integer) o.getWeight()).compareTo(weight);
	}
}
