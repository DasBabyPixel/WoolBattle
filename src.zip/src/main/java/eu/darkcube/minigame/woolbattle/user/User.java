package eu.darkcube.minigame.woolbattle.user;

import java.util.UUID;

import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;

import eu.darkcube.minigame.woolbattle.perk.Perk;
import eu.darkcube.minigame.woolbattle.team.Team;
import eu.darkcube.minigame.woolbattle.translation.Language;
import eu.darkcube.minigame.woolbattle.util.InventoryId;
import net.minecraft.server.v1_8_R3.Packet;

public interface User {

	UUID getUniqueId();

	String getPlayerName();

	String getTeamPlayerName();

	Language getLanguage();

	void setLanguage(Language language);

	Team getTeam();

	void setTeam(Team team);

	UserData getData();

	void loadPerks();
	
	Perk getActivePerk1();
	
	Perk getActivePerk2();
	
	Perk getPassivePerk();
	
	Perk getEnderPearl();

	Perk getPerkByItemId(String itemId);
	
	void sendPacket(Packet<?> packet);

	int getMaxWoolSize();

	int getWoolBreakAmount();

	int getSpawnProtectionTicks();

	boolean hasSpawnProtection();

	void setSpawnProtectionTicks(int ticks);

	void setTrollMode(boolean trollmode);

	boolean isTrollMode();

	CraftPlayer getBukkitEntity();

	InventoryId getOpenInventory();

	void setOpenInventory(InventoryId id);

	User getLastHit();
	
	void setLastHit(User user);
	
	int getTicksAfterLastHit();
	
	void setTicksAfterLastHit(int ticks);
	
	int getKills();

	int getDeaths();
	
	double getKD();

	void setKills(int kills);

	void setDeaths(int deaths);

}