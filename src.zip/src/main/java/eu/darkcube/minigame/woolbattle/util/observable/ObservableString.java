package eu.darkcube.minigame.woolbattle.util.observable;

public interface ObservableString extends ObservableObject<String> {

}
