package eu.darkcube.minigame.woolbattle.perk;

import eu.darkcube.minigame.woolbattle.user.User;
import eu.darkcube.minigame.woolbattle.util.Item;

public enum PerkType implements Comparable<PerkType> {

	CAPSULE(Item.PERK_CAPSULE, Item.PERK_CAPSULE_COOLDOWN, 30, PerkName.CAPSULE, false, 24),

	SWITCHER(Item.PERK_SWITCHER, Item.PERK_SWITCHER_COOLDOWN, 7, PerkName.SWITCHER, false, 8),

	LINE_BUILDER(Item.PERK_LINE_BUILDER, Item.PERK_LINE_BUILDER_COOLDOWN, 10, PerkName.LINE_BUILDER, false, 2),

	WOOL_BOMB(Item.PERK_WOOL_BOMB, Item.PERK_WOOL_BOMB_COOLDOWN, 5, PerkName.WOOL_BOMB, false, 5),

	RONJAS_TOILET_SPLASH(Item.PERK_RONJAS_TOILET_SPLASH, Item.PERK_RONJAS_TOILET_SPLASH_COOLDOWN, 13,
			PerkName.RONJAS_TOILET_SPLASH, false, 12),

	BLINK(Item.PERK_BLINK, Item.PERK_BLINK_COOLDOWN, 15, PerkName.BLINK, false, 12),
	
	DOUBLE_WOOL(Item.PERK_DOUBLE_WOOL, Item.PERK_DOUBLE_WOOL, 0, PerkName.DOUBLE_WOOL, true, 0),

	BACKPACK(Item.PERK_BACKPACK, Item.PERK_BACKPACK, 0, PerkName.BACKPACK, true, 0),

	ROCKETJUMP(Item.PERK_ROCKETJUMP, Item.PERK_ROCKETJUMP, 0, PerkName.ROCKETJUMP, true, 0),

	ARROW_RAIN(Item.PERK_ARROW_RAIN, Item.PERK_ARROW_RAIN_COOLDOWN, 10, PerkName.ARROW_RAIN, true, 5),;

	private final Item item;
	private final Item cooldownItem;
	private final PerkName perkName;
	private final int cooldown;
	private final int cost;
	private final boolean passive;

	PerkType(Item item, Item cooldownItem, int cooldown, PerkName perkName, boolean passive, int cost) {
		this.cost = cost;
		this.passive = passive;
		this.cooldownItem = cooldownItem;
		this.item = item;
		this.perkName = perkName;
		this.cooldown = cooldown;
	}

	public Perk newPerkTypePerk(User owner, PerkNumber perkNumber) {
		return new PerkTypePerk(this, owner, perkNumber);
	}

	public PerkName getPerkName() {
		return perkName;
	}

	public Item getItem() {
		return item;
	}

	public int getCost() {
		return cost;
	}

	public boolean isPassive() {
		return passive;
	}

	public Item getCooldownItem() {
		return cooldownItem;
	}

	public boolean hasCooldown() {
		return getCooldown() != 0;
	}

	public int getCooldown() {
		return cooldown;
	}

	public static PerkType valueOf(PerkName name) {
		for (PerkType type : values()) {
			if (type.getPerkName().equals(name))
				return type;
		}
		return null;
	}
}
