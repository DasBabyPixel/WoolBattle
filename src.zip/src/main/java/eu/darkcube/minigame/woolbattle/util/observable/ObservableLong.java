package eu.darkcube.minigame.woolbattle.util.observable;

public interface ObservableLong extends ObservableObject<Long>{

}
