package eu.darkcube.minigame.woolbattle.listener.ingame;

import java.util.Random;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

import eu.darkcube.minigame.woolbattle.Main;
import eu.darkcube.minigame.woolbattle.game.Ingame;
import eu.darkcube.minigame.woolbattle.listener.Listener;
import eu.darkcube.minigame.woolbattle.team.TeamType;
import eu.darkcube.minigame.woolbattle.user.User;
import eu.darkcube.minigame.woolbattle.util.scheduler.Scheduler;
import net.minecraft.server.v1_8_R3.Blocks;
import net.minecraft.server.v1_8_R3.EntityFallingBlock;

public class ListenerEntityDamageByEntity extends Listener<EntityDamageByEntityEvent> {

	@Override
	@EventHandler
	public void handle(EntityDamageByEntityEvent e) {
		if (e.getEntity() instanceof Player) {
			e.setDamage(0);
			Main main = Main.getInstance();
			User target = main.getUserWrapper().getUser(e.getEntity().getUniqueId());
			Ingame ingame = main.getIngame();
			if (target.hasSpawnProtection() || ingame.isGlobalSpawnProtection) {
				e.setCancelled(true);
				return;
			}
			if (e.getDamager() instanceof Player) {
				User user = main.getUserWrapper().getUser(e.getDamager().getUniqueId());
				if (!user.isTrollMode()) {
					if (e.isCancelled())
						return;
					if (user.getTeam().getType() == TeamType.SPECTATOR) {
						e.setCancelled(true);
						return;
					}
				}
				if (target.getTeam().equals(user.getTeam()) && !user.isTrollMode()) {
					e.setCancelled(true);
					return;
				}
				if (user.hasSpawnProtection() && !user.isTrollMode()) {
					user.setSpawnProtectionTicks(0);
				}
				ingame.attack(user, target);
			} else if (e.getDamager() instanceof Arrow) {

				Arrow arrow = (Arrow) e.getDamager();
				if (arrow.getShooter() instanceof Player) {
					Player p = (Player) arrow.getShooter();
					User user = Main.getInstance().getUserWrapper().getUser(p.getUniqueId());

					if (!user.isTrollMode()) {
						if (target.getUniqueId().equals(user.getUniqueId()) || user.getTeam().equals(target.getTeam())
								|| user.getTeam().getType() == TeamType.SPECTATOR) {
							e.setCancelled(true);
							return;
						}
					}

					e.setCancelled(true);
					if (target.getTicksAfterLastHit() >= 11) {
						if (target.hasSpawnProtection()) {
							arrow.remove();
							return;
						}

						Main.getInstance().getIngame().attack(user, target);
						target.getBukkitEntity().damage(0);
						user.getBukkitEntity().playSound(user.getBukkitEntity().getLocation(), Sound.SUCCESSFUL_HIT, 1,
								0);
						new Scheduler() {
							Location loc = target.getBukkitEntity().getLocation();

							@SuppressWarnings("deprecation")
							@Override
							public void run() {
								for (double xoff = -.5; xoff < 1.5; xoff++) {
									for (double yoff = -1; yoff < 3; yoff++) {
										for (double zoff = -.5; zoff < 1.5; zoff++) {
											Location l = loc.clone().add(xoff, yoff, zoff);
											Block b = l.getBlock();
											if (b.getType() == Material.WOOL) {
												int dmg = Ingame.getBlockDamage(b);
												if (dmg >= 2) {
													Random r = new Random();
													double x = r.nextBoolean() ? r.nextDouble() / 3
															: -r.nextDouble() / 3, y = r.nextDouble() / 2,
															z = r.nextBoolean() ? r.nextDouble() / 3
																	: -r.nextDouble() / 3;
													EntityFallingBlock block = new EntityFallingBlock(
															((CraftWorld) b.getWorld()).getHandle(),
															b.getLocation().getBlockX() + .5,
															b.getLocation().getBlockY() + .5,
															b.getLocation().getBlockZ() + .5,
															Blocks.WOOL.fromLegacyData(b.getData()));
													Ingame.setBlockDamage(b, dmg + 1);
													block.ticksLived = 1;
													block.dropItem = false;
													block.motX = x;
													block.motY = y;
													block.motZ = z;
													block.velocityChanged = true;
													block.world.addEntity(block);
												} else
													Ingame.setBlockDamage(b, dmg + 1);
											}
										}
									}
								}
							}
						}.runTaskLater(3);
						target.getBukkitEntity()
								.setVelocity(arrow.getVelocity().setY(0).normalize().multiply(
										.47 + new Random().nextDouble() / 70 + arrow.getKnockbackStrength() / 1.42)
										.setY(.400023));
						arrow.remove();
					} else {
						arrow.remove();
					}
				}
			}
		} else {
			e.setCancelled(true);
		}
	}
}