package eu.darkcube.minigame.woolbattle.listener.ingame;

import org.bukkit.Material;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.inventory.ItemStack;

import eu.darkcube.minigame.woolbattle.Main;
import eu.darkcube.minigame.woolbattle.game.Ingame;
import eu.darkcube.minigame.woolbattle.listener.Listener;
import eu.darkcube.minigame.woolbattle.perk.PerkEnderPearl;
import eu.darkcube.minigame.woolbattle.perk.PerkType;
import eu.darkcube.minigame.woolbattle.user.User;
import eu.darkcube.minigame.woolbattle.util.ItemManager;
import eu.darkcube.minigame.woolbattle.util.scheduler.Scheduler;

public class ListenerProjectileLaunch extends Listener<ProjectileLaunchEvent> {
	@Override
	@EventHandler
	public void handle(ProjectileLaunchEvent e) {
		if (e.getEntity().getShooter() instanceof Player) {
			Player p = (Player) e.getEntity().getShooter();
			User user = Main.getInstance().getUserWrapper().getUser(p.getUniqueId());
			if (e.getEntityType() == EntityType.ARROW) {
				Arrow arrow = (Arrow) e.getEntity();

				if (!p.getInventory().contains(Material.WOOL, 1)) {
					Ingame.playSoundNotEnoughWool(user);
					arrow.remove();
					e.setCancelled(true);
					return;
				}
				ItemManager.removeItems(p.getInventory(),
						new ItemStack(Material.WOOL, 1, user.getTeam().getType().getWoolColor()), 1);
				if (user.getPassivePerk().getPerkName().equals(PerkType.ARROW_RAIN.getPerkName())) {
					if (!p.getInventory().contains(Material.WOOL, PerkType.ARROW_RAIN.getCost())) {
						Ingame.playSoundNotEnoughWool(user);
						new Scheduler() {
							@Override
							public void run() {
								user.getPassivePerk().setItem();
							}
						}.runTask();
						e.setCancelled(true);
						return;
					}
					if (user.getPassivePerk().getCooldown() > 0) {
						user.getPassivePerk().setCooldown(user.getPassivePerk().getCooldown() - 1);
						return;
					}

					ItemManager.removeItems(p.getInventory(),
							new ItemStack(Material.WOOL, 1, user.getTeam().getType().getWoolColor()),
							PerkType.ARROW_RAIN.getCost());

					user.getPassivePerk().setCooldown(user.getPassivePerk().getMaxCooldown() + 4);

					for (int i = 0; i < 4; i++) {
						p.launchProjectile(Arrow.class);
					}
				}

				Main.getInstance().getIngame().arrows.add(arrow);
			} else if (e.getEntityType() == EntityType.ENDER_PEARL) {

				if (user.getEnderPearl().getCooldown() > 0
						|| !p.getInventory().contains(Material.WOOL, PerkEnderPearl.COST)) {
					Ingame.playSoundNotEnoughWool(user);
					new Scheduler() {
						@Override
						public void run() {
							user.getEnderPearl().setItem();
						}
					}.runTask();
					e.setCancelled(true);
					return;
				}

				ItemManager.removeItems(p.getInventory(),
						new ItemStack(Material.WOOL, 1, user.getTeam().getType().getWoolColor()), PerkEnderPearl.COST);

				new Scheduler() {
					int cd = user.getEnderPearl().getMaxCooldown() + 1;

					@Override
					public void run() {
						if (cd <= 1) {
							this.cancel();
							user.getEnderPearl().setCooldown(0);
							return;
						}
						user.getEnderPearl().setCooldown(--cd);
					}
				}.runTaskTimer(20);
			}
		}
	}
}
