package eu.darkcube.minigame.woolbattle.game;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scoreboard.DisplaySlot;

import eu.darkcube.minigame.woolbattle.Config;
import eu.darkcube.minigame.woolbattle.Main;
import eu.darkcube.minigame.woolbattle.event.EventDamageBlock;
import eu.darkcube.minigame.woolbattle.event.EventDestroyBlock;
import eu.darkcube.minigame.woolbattle.event.EventPlayerDeath;
import eu.darkcube.minigame.woolbattle.event.EventPlayerKill;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerBlockBreak;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerBlockCanBuild;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerBlockPlace;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerChangeBlock;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerEntityDamage;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerEntityDamageByEntity;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerEntitySpawn;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerGameModeChange;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerInteract;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerInventoryClick;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerInventoryDrag;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerItemDrop;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerItemPickup;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerPlayerJoin;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerPlayerMove;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerPlayerQuit;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerProjectileHit;
import eu.darkcube.minigame.woolbattle.listener.ingame.ListenerProjectileLaunch;
import eu.darkcube.minigame.woolbattle.listener.ingame.perk.ListenerBlinkInteract;
import eu.darkcube.minigame.woolbattle.listener.ingame.perk.ListenerCapsule;
import eu.darkcube.minigame.woolbattle.listener.ingame.perk.ListenerLineBuilderInteract;
import eu.darkcube.minigame.woolbattle.listener.ingame.perk.ListenerRonjasToiletEntityDamageByEntity;
import eu.darkcube.minigame.woolbattle.listener.ingame.perk.ListenerRonjasToiletHit;
import eu.darkcube.minigame.woolbattle.listener.ingame.perk.ListenerRonjasToiletInteract;
import eu.darkcube.minigame.woolbattle.listener.ingame.perk.ListenerRonjasToiletLaunch;
import eu.darkcube.minigame.woolbattle.listener.ingame.perk.ListenerSwitcherLaunch;
import eu.darkcube.minigame.woolbattle.listener.ingame.perk.ListenerSwitcherSwitch;
import eu.darkcube.minigame.woolbattle.listener.ingame.perk.ListenerWoolBombEntityDamageByEntity;
import eu.darkcube.minigame.woolbattle.listener.ingame.perk.ListenerWoolBombExplode;
import eu.darkcube.minigame.woolbattle.listener.ingame.perk.ListenerWoolBombHit;
import eu.darkcube.minigame.woolbattle.listener.ingame.perk.ListenerWoolBombInteract;
import eu.darkcube.minigame.woolbattle.listener.ingame.perk.ListenerWoolBombLaunch;
import eu.darkcube.minigame.woolbattle.listener.ingame.standard.ListenerDoubleJump;
import eu.darkcube.minigame.woolbattle.listener.lobby.ListenerPlayerLogin;
import eu.darkcube.minigame.woolbattle.perk.PlayerPerks;
import eu.darkcube.minigame.woolbattle.team.Team;
import eu.darkcube.minigame.woolbattle.team.TeamType;
import eu.darkcube.minigame.woolbattle.translation.Message;
import eu.darkcube.minigame.woolbattle.user.User;
import eu.darkcube.minigame.woolbattle.util.Characters;
import eu.darkcube.minigame.woolbattle.util.CloudNetLink;
import eu.darkcube.minigame.woolbattle.util.Enableable;
import eu.darkcube.minigame.woolbattle.util.Item;
import eu.darkcube.minigame.woolbattle.util.ItemBuilder;
import eu.darkcube.minigame.woolbattle.util.ItemManager;
import eu.darkcube.minigame.woolbattle.util.ParticleEffect;
import eu.darkcube.minigame.woolbattle.util.ScoreboardObjective;
import eu.darkcube.minigame.woolbattle.util.scheduler.Scheduler;
import eu.darkcube.minigame.woolbattle.util.scoreboard.Objective;
import eu.darkcube.minigame.woolbattle.util.scoreboard.Scoreboard;
import eu.darkcube.minigame.woolbattle.util.tab.Footer;
import eu.darkcube.minigame.woolbattle.util.tab.Header;
import eu.darkcube.minigame.woolbattle.util.tab.TabManager;

public class Ingame implements Enableable {

	public static int MAX_BLOCK_ARROW_HITS = Main.getInstance().getConfig("config").getInt("maxblockarrowhits");
	public static int SPAWNPROTECTION_TICKS = Main.getInstance().getConfig("config").getInt("spawnprotectionticks");
	public static int SPAWNPROTECTION_TICKS_GLOBAL = Main.getInstance().getConfig("config")
			.getInt("spawnprotectionticksglobal");

	public Set<Block> placedBlocks = new HashSet<>();
	public Set<Arrow> arrows = new HashSet<>();
	public Collection<Player> particlePlayers = new HashSet<>();
	public Map<Block, Byte> breakedWool = new HashMap<>();
	public final ListenerBlockBreak listenerBlockBreak;
	public final ListenerBlockPlace listenerBlockPlace;
	public final ListenerItemDrop listenerItemDrop;
	public final ListenerItemPickup listenerItemPickup;
	public final ListenerBlockCanBuild listenerBlockCanBuild;
	public final ListenerPlayerJoin listenerPlayerJoin;
	public final ListenerPlayerQuit listenerPlayerQuit;
	public final ListenerPlayerLogin listenerPlayerLogin;
	public final ListenerEntityDamageByEntity listenerEntityDamageByEntity;
	public final ListenerDoubleJump listenerDoubleJump;
	public final ListenerEntityDamage listenerEntityDamage;
	public final ListenerChangeBlock listenerChangeBlock;
	public final ListenerProjectileHit listenerProjectileHit;
	public final ListenerProjectileLaunch listenerProjectileLaunch;
	public final ListenerInventoryClick listenerInventoryClick;
	public final ListenerInventoryDrag listenerInventoryDrag;
	public final ListenerCapsule listenerCapsule;
	public final ListenerSwitcherLaunch listenerSwitcherLaunch;
	public final ListenerSwitcherSwitch listenerSwitcherSwitch;
	public final ListenerInteract listenerInteract;
	public final ListenerGameModeChange listenerGameModeChange;
	public final ListenerPlayerMove listenerPlayerMove;
	public final ListenerEntitySpawn listenerEntitySpawn;
	public final ListenerWoolBombInteract listenerWoolBombInteract;
	public final ListenerWoolBombLaunch listenerWoolBombLaunch;
	public final ListenerWoolBombEntityDamageByEntity listenerWoolBombEntityDamageByEntity;
	public final ListenerWoolBombHit listenerWoolBombHit;
	public final ListenerWoolBombExplode listenerWoolBombExplode;
	public final ListenerLineBuilderInteract listenerLineBuilderInteract;
	public final ListenerRonjasToiletInteract listenerRonjasToiletInteract;
	public final ListenerRonjasToiletLaunch listenerRonjasToiletLaunch;
	public final ListenerRonjasToiletHit listenerRonjasToiletHit;
	public final ListenerRonjasToiletEntityDamageByEntity listenerRonjasToiletEntityDamageByEntity;
	public final ListenerBlinkInteract listenerBlinkInteract;
	public final Scheduler schedulerResetWool;
	public final Scheduler schedulerResetSpawnProtetion;
	public final Scheduler schedulerParticles;
	public final Scheduler schedulerGlobalSpawnProtection;
	public final Scheduler schedulerTick;
	public final Scheduler schedulerDeathTimer;
	public boolean isGlobalSpawnProtection = false;
	public Team winner;

	public Ingame() {
		listenerItemPickup = new ListenerItemPickup();
		listenerItemDrop = new ListenerItemDrop();
		listenerBlockBreak = new ListenerBlockBreak();
		listenerBlockPlace = new ListenerBlockPlace();
		listenerBlockCanBuild = new ListenerBlockCanBuild();
		listenerPlayerJoin = new ListenerPlayerJoin();
		listenerPlayerQuit = new ListenerPlayerQuit();
		listenerPlayerLogin = new ListenerPlayerLogin();
		listenerEntityDamageByEntity = new ListenerEntityDamageByEntity();
		listenerDoubleJump = new ListenerDoubleJump();
		listenerEntityDamage = new ListenerEntityDamage();
		listenerChangeBlock = new ListenerChangeBlock();
		listenerProjectileHit = new ListenerProjectileHit();
		listenerProjectileLaunch = new ListenerProjectileLaunch();
		listenerInventoryClick = new ListenerInventoryClick();
		listenerInventoryDrag = new ListenerInventoryDrag();
		listenerCapsule = new ListenerCapsule();
		listenerSwitcherLaunch = new ListenerSwitcherLaunch();
		listenerSwitcherSwitch = new ListenerSwitcherSwitch();
		listenerInteract = new ListenerInteract();
		listenerGameModeChange = new ListenerGameModeChange();
		listenerPlayerMove = new ListenerPlayerMove();
		listenerEntitySpawn = new ListenerEntitySpawn();
		listenerWoolBombInteract = new ListenerWoolBombInteract();
		listenerWoolBombLaunch = new ListenerWoolBombLaunch();
		listenerWoolBombEntityDamageByEntity = new ListenerWoolBombEntityDamageByEntity();
		listenerWoolBombHit = new ListenerWoolBombHit();
		listenerWoolBombExplode = new ListenerWoolBombExplode();
		listenerLineBuilderInteract = new ListenerLineBuilderInteract();
		listenerRonjasToiletInteract = new ListenerRonjasToiletInteract();
		listenerRonjasToiletLaunch = new ListenerRonjasToiletLaunch();
		listenerRonjasToiletHit = new ListenerRonjasToiletHit();
		listenerRonjasToiletEntityDamageByEntity = new ListenerRonjasToiletEntityDamageByEntity();
		listenerBlinkInteract = new ListenerBlinkInteract();

		schedulerParticles = new Scheduler() {
			@Override
			public void run() {
				Set<Arrow> aarrows = new HashSet<>(arrows);
				Set<Arrow> aaarrows = new HashSet<>(aarrows);
				for (Arrow arrow : aaarrows) {
					if (!arrow.getLocation().getChunk().isLoaded()) {
						arrow.getLocation().getChunk().load();
					}
					if (arrow.getShooter() instanceof Player) {
						if (arrow.isDead() || arrow.isOnGround() || !arrow.isValid()) {
							arrow.remove();
							arrows.remove(arrow);
							break;
						}
						User user = Main.getInstance().getUserWrapper()
								.getUser(((Player) arrow.getShooter()).getUniqueId());
						ParticleEffect.BLOCK_CRACK.display(
								new ParticleEffect.BlockData(Material.WOOL, user.getTeam().getType().getWoolColor()), 0,
								0, 0, 1, 8, arrow.getLocation(), particlePlayers);
					}
				}
			}
		};
		schedulerGlobalSpawnProtection = new Scheduler() {
			public int protectionTicks = SPAWNPROTECTION_TICKS_GLOBAL;

			@Override
			public void run() {
				if (protectionTicks - 1 <= 0 || SPAWNPROTECTION_TICKS_GLOBAL == 0) {
					protectionTicks = SPAWNPROTECTION_TICKS_GLOBAL;
					this.cancel();
					return;
				}
				isGlobalSpawnProtection = true;
				protectionTicks--;
				for (User user : Main.getInstance().getUserWrapper().getUsers()) {
					user.getBukkitEntity().setExp((float) protectionTicks / (float) SPAWNPROTECTION_TICKS_GLOBAL);
				}
			}

			@Override
			public void cancel() {
				if (!isCancelled()) {
					isGlobalSpawnProtection = false;
					schedulerResetSpawnProtetion.runTaskTimer(1);
					super.cancel();
				}
			}
		};
		schedulerTick = new Scheduler() {
			@Override
			public void run() {
				for (User user : Main.getInstance().getUserWrapper().getUsers()) {
					if (user.getTeam().getType() != TeamType.SPECTATOR) {
						if (user.getTicksAfterLastHit() < 1200)
							user.setTicksAfterLastHit(user.getTicksAfterLastHit() + 1);
					}
				}
			}
		};
		schedulerResetSpawnProtetion = new Scheduler() {
			@Override
			public void run() {
				for (User user : Main.getInstance().getUserWrapper().getUsers()) {
					if (SPAWNPROTECTION_TICKS != 0) {
						if (user.getSpawnProtectionTicks() > 0) {
							user.setSpawnProtectionTicks(user.getSpawnProtectionTicks() - 1);
						}
					}
				}
			}
		};
		schedulerResetWool = new Scheduler() {
			@SuppressWarnings("deprecation")
			@Override
			public synchronized void run() {
				for (Block b : breakedWool.keySet()) {
					b.setType(Material.WOOL);
					b.setData(breakedWool.get(b));
				}
				breakedWool.clear();
			}
		};
		schedulerDeathTimer = new Scheduler() {
			Main main = Main.getInstance();

			@Override
			public void run() {
				for (User user : main.getUserWrapper().getUsers()) {
					if (user.getTeam().getType() != TeamType.SPECTATOR) {
						if (user.getBukkitEntity().getLocation().getBlockY() <= main.getMap().getDeathHeight()) {
							if (user.getTicksAfterLastHit() <= 200) {
								kill(user);
								user.setTicksAfterLastHit(201);
							} else {
								user.getBukkitEntity().teleport(user.getTeam().getSpawn());
							}
						}
					}
				}
			}
		};
	}

	@Override
	public void onEnable() {
		CloudNetLink.update();
		splitPlayersToTeams();
		Main.getInstance().getSchedulers().clear();
		int lifes = -1;
		if (Main.getInstance().baseLifes != null)
			lifes = Main.getInstance().baseLifes;
		if (lifes == -1) {
			int xtra = 0;
			int playersize = Bukkit.getOnlinePlayers().size();
			if (playersize < 3) {
				xtra = new Random().nextInt(playersize / 2);
			} else {
				playersize = 3;
				xtra = new Random().nextInt(4);
			}
			xtra += playersize;
			lifes = 10 + xtra;
		}
		for (Team team : Main.getInstance().getTeamManager().getTeams()) {
			team.setLifes(lifes);
		}
		

		listenerLineBuilderInteract.cooldownTasks.clear();
		listenerLineBuilderInteract.lastLine.clear();
		listenerLineBuilderInteract.lines.clear();
		listenerLineBuilderInteract.placeTasks.clear();
		listenerDoubleJump.cooldown.clear();
		listenerPlayerMove.ghostBlockFixCount.clear();

		Main.registerListeners(listenerBlockBreak);
		Main.registerListeners(listenerBlockPlace);
		Main.registerListeners(listenerItemDrop);
		Main.registerListeners(listenerItemPickup);
		Main.registerListeners(listenerBlockCanBuild);
		Main.registerListeners(listenerPlayerJoin);
		Main.registerListeners(listenerPlayerQuit);
		Main.registerListeners(listenerPlayerLogin);
		Main.registerListeners(listenerEntityDamageByEntity);
		Main.registerListeners(listenerDoubleJump);
		Main.registerListeners(listenerEntityDamage);
		Main.registerListeners(listenerChangeBlock);
		Main.registerListeners(listenerProjectileHit);
		Main.registerListeners(listenerProjectileLaunch);
		Main.registerListeners(listenerInventoryClick);
		Main.registerListeners(listenerInventoryDrag);
		Main.registerListeners(listenerCapsule);
		Main.registerListeners(listenerSwitcherLaunch);
		Main.registerListeners(listenerSwitcherSwitch);
		Main.registerListeners(listenerInteract);
		Main.registerListeners(listenerGameModeChange);
		Main.registerListeners(listenerPlayerMove);
		Main.registerListeners(listenerEntitySpawn);

		Main.registerListeners(listenerWoolBombInteract);
		Main.registerListeners(listenerWoolBombLaunch);
		Main.registerListeners(listenerWoolBombEntityDamageByEntity);
		Main.registerListeners(listenerWoolBombHit);
		Main.registerListeners(listenerWoolBombExplode);
		Main.registerListeners(listenerLineBuilderInteract);
		Main.registerListeners(listenerRonjasToiletInteract);
		Main.registerListeners(listenerRonjasToiletHit);
		Main.registerListeners(listenerRonjasToiletEntityDamageByEntity);
		Main.registerListeners(listenerRonjasToiletLaunch);
		Main.registerListeners(listenerBlinkInteract);

		Main.getInstance().getUserWrapper().getUsers().forEach(u -> {
			loadScoreboardObjective(u);
			u.loadPerks();
			setPlayerItems(u);
			u.setTicksAfterLastHit(1200);
			u.getBukkitEntity().teleport(u.getTeam().getSpawn());
		});

		isGlobalSpawnProtection = true;

		schedulerResetWool.runTaskTimer(16);
		schedulerParticles.runTaskTimer(1);
		// This one also starts the normal spawnprotection scheduler
		schedulerGlobalSpawnProtection.runTaskTimer(1);
		schedulerTick.runTaskTimer(1);
		schedulerDeathTimer.runTaskTimer(15);
	}

	@Override
	public void onDisable() {
		schedulerGlobalSpawnProtection.cancel();
		schedulerResetSpawnProtetion.cancel();
		schedulerParticles.cancel();
		schedulerResetWool.cancel();
		schedulerTick.cancel();
		schedulerDeathTimer.cancel();
		Main.unregisterListeners(listenerBlockBreak);
		Main.unregisterListeners(listenerBlockPlace);
		Main.unregisterListeners(listenerItemDrop);
		Main.unregisterListeners(listenerItemPickup);
		Main.unregisterListeners(listenerBlockCanBuild);
		Main.unregisterListeners(listenerPlayerJoin);
		Main.unregisterListeners(listenerPlayerQuit);
		Main.unregisterListeners(listenerPlayerLogin);
		Main.unregisterListeners(listenerEntityDamageByEntity);
		Main.unregisterListeners(listenerDoubleJump);
		Main.unregisterListeners(listenerEntityDamage);
		Main.unregisterListeners(listenerChangeBlock);
		Main.unregisterListeners(listenerProjectileHit);
		Main.unregisterListeners(listenerProjectileLaunch);
		Main.unregisterListeners(listenerInventoryClick);
		Main.unregisterListeners(listenerInventoryDrag);
		Main.unregisterListeners(listenerCapsule);
		Main.unregisterListeners(listenerSwitcherLaunch);
		Main.unregisterListeners(listenerSwitcherSwitch);
		Main.unregisterListeners(listenerInteract);
		Main.unregisterListeners(listenerGameModeChange);
		Main.unregisterListeners(listenerPlayerMove);
		Main.unregisterListeners(listenerEntitySpawn);

		Main.unregisterListeners(listenerWoolBombInteract);
		Main.unregisterListeners(listenerWoolBombLaunch);
		Main.unregisterListeners(listenerWoolBombEntityDamageByEntity);
		Main.unregisterListeners(listenerWoolBombHit);
		Main.unregisterListeners(listenerWoolBombExplode);
		Main.unregisterListeners(listenerLineBuilderInteract);
		Main.unregisterListeners(listenerRonjasToiletInteract);
		Main.unregisterListeners(listenerRonjasToiletHit);
		Main.unregisterListeners(listenerRonjasToiletEntityDamageByEntity);
		Main.unregisterListeners(listenerRonjasToiletLaunch);
		Main.unregisterListeners(listenerBlinkInteract);
	}

	public void kill(User user) {
		kill(user, false);
	}

	@SuppressWarnings("null")
	public void kill(User user, boolean leaving) {
		User killer = user.getLastHit();
		EventPlayerDeath pe1 = new EventPlayerDeath(user);
		Bukkit.getPluginManager().callEvent(pe1);
		boolean countAsDeath = killer != null ? user.getTicksAfterLastHit() <= 200 : false;
		if (countAsDeath) {
			EventPlayerKill pe2 = new EventPlayerKill(user, killer);
			Bukkit.getPluginManager().callEvent(pe2);
			if (!pe2.isCancelled()) {
				killer.setKills(killer.getKills() + 1);
				user.setDeaths(user.getDeaths() + 1);
			}
		}

		if (!countAsDeath && !leaving) {
			user.getBukkitEntity().teleport(user.getTeam().getSpawn());
			return;
		}
		Map<Message, Function<User, String[]>> msgs = new HashMap<>();
		if (killer != null) {
			if (user.getTicksAfterLastHit() < 140) {
				msgs.put(Message.PLAYER_WAS_KILLED_BY_PLAYER,
						u -> new String[] { user.getTeamPlayerName(), killer.getTeamPlayerName() });
			} else if (user.getTicksAfterLastHit() <= 200) {
				msgs.put(Message.PLAYER_DIED, u -> new String[] { user.getTeamPlayerName() });
			} else {
				msgs.put(Message.PLAYER_DIED, u -> new String[] { "Player should not be able to die" });
			}
		}

		if (user.getTeam().getUsers().size() == 1 && (user.getTeam().getLifes() == 0 || leaving)) {
			msgs.put(Message.TEAM_WAS_ELIMINATED, u -> new String[] { user.getTeam().getName(u) });
			for (Entry<Message, Function<User, String[]>> msg : msgs.entrySet()) {
				Main.getInstance().sendMessage(msg.getKey(), msg.getValue());
			}
			setSpectator(user);
			List<Team> teams = Main.getInstance().getTeamManager().getTeams().stream()
					.filter(t -> t.getUsers().size() >= 1).collect(Collectors.toList());
			if (teams.size() == 1) {
				if (leaving) {
					user.getBukkitEntity().kickPlayer("Disconnected");
				}
				this.winner = teams.get(0);
				disable();
				Main.getInstance().getEndgame().enable();
				return;
			}
		}
		for (Entry<Message, Function<User, String[]>> msg : msgs.entrySet()) {
			Main.getInstance().sendMessage(msg.getKey(), msg.getValue());
		}
		if (countAsDeath) {
			if (user.getTeam().getLifes() > 0) {
				user.getTeam().setLifes(user.getTeam().getLifes() - 1);
			}
		}
		user.getBukkitEntity().teleport(user.getTeam().getSpawn());
		user.setSpawnProtectionTicks(SPAWNPROTECTION_TICKS);
	}

	public void loadScoreboardObjective(User user) {
		Scoreboard sb = new Scoreboard(user);
		Objective obj = sb.getObjective(ScoreboardObjective.INGAME.getKey());
		int i = 0;
		for (Team team : Main.getInstance().getTeamManager().getTeams()) {
			eu.darkcube.minigame.woolbattle.util.scoreboard.Team t = sb
					.getTeam(team.getType().getIngameScoreboardTag());
			t.addPlayer(team.getType().getInvisibleTag());
			t.setSuffix(ChatColor.GOLD.toString() + Characters.SHIFT_SHIFT_LEFT + team.getName(user));
			obj.setScore(team.getType().getInvisibleTag(), i++);
			reloadScoreboardLifes(sb, team);
		}
		obj.setDisplaySlot(DisplaySlot.SIDEBAR);
	}

	public synchronized void splitPlayersToTeams() {
		Collection<? extends Team> teams = Main.getInstance().getTeamManager().getTeams();
		int chosenCount = 0;
		for (Team team : teams) {
			chosenCount += team.getUsers().size();
		}
		if (chosenCount == Main.getInstance().getUserWrapper().getUsers().size()) {
			if (chosenCount == 0) {
				throw new Error("Starting game without players!");
			}
			Set<User> users1 = new HashSet<>();
			for (Team team : teams) {
				if (team.getUsers().size() == chosenCount) {
					int half = team.getUsers().size() / 2;
					while (users1.size() < half) {
						Optional<? extends User> o = team.getUsers().stream().findAny();
						if (o.isPresent()) {
							User user = o.get();
							users1.add(user);
						} else {
							Main.getInstance().sendConsole("§cUser of team was somehow not found");
						}
					}
					break;
				}
			}
			if (users1.size() != 0) {
				for (Team team : teams) {
					if (team.getUsers().size() == 0) {
						for (User user : users1) {
							user.setTeam(team);
						}
						break;
					}
				}
			}
		}
		int max = teams.stream().findAny().get().getType().getMaxPlayers();
		for (int i = 0; i < max; i++) {
			for (Team team : teams) {
				if (team.getUsers().size() == i) {
					for (User user : Main.getInstance().getUserWrapper().getUsers()) {
						if (user.getTeam().getType() == TeamType.SPECTATOR) {
							user.setTeam(team);
							break;
						}
					}
				}
			}
		}
	}

	@SuppressWarnings("deprecation")
	public void setPlayerItems(User user) {
		CraftPlayer p = user.getBukkitEntity();
		InventoryView v = p.getOpenInventory();
		int woolcount = ItemManager.countItems(Material.WOOL, p.getInventory());
		v.getBottomInventory().clear();
		v.getTopInventory().clear();
		v.setCursor(new ItemStack(Material.AIR));

		Color color = DyeColor.getByData(user.getTeam().getType().getWoolColor()).getColor();
		ItemStack boots = Item.ARMOR_LEATHER_BOOTS.getItem(user);
		LeatherArmorMeta meta = (LeatherArmorMeta) boots.getItemMeta();
		meta.setColor(color);

		boots.setItemMeta(meta.clone());
		ItemStack leggings = Item.ARMOR_LEATHER_LEGGINGS.getItem(user);
		leggings.setItemMeta(meta.clone());
		ItemStack chest = Item.ARMOR_LEATHER_CHESTPLATE.getItem(user);
		chest.setItemMeta(meta.clone());
		ItemStack helmet = Item.ARMOR_LEATHER_HELMET.getItem(user);
		helmet.setItemMeta(meta.clone());
		p.getInventory().setArmorContents(new ItemStack[] { boots, leggings, chest, helmet });

		PlayerPerks perks = user.getData().getPerks();

		setPlayerItem(v, perks.getSlotBow(), Item.DEFAULT_BOW.getItem(user));
		setPlayerItem(v, perks.getSlotArrow(), Item.DEFAULT_ARROW.getItem(user));
//		v.setItem(perks.getSlotBow(), Item.DEFAULT_BOW.getItem(user));
//		v.setItem(perks.getSlotArrow(), Item.DEFAULT_ARROW.getItem(user));
		setPlayerItem(v, perks.getSlotShears(), Item.DEFAULT_SHEARS.getItem(user));
		user.getEnderPearl().setItem();
//		v.setItem(user.getData().getPerks().getSlotPearl(), Item.DEFAULT_PEARL.getItem(user));
//		v.setItem(perks.getSlotShears(), Item.DEFAULT_SHEARS.getItem(user));

		user.getActivePerk1().setItem();
		user.getActivePerk2().setItem();
		user.getPassivePerk().setItem();

//		v.setItem(user.getData().getPerks().getSlotActivePerk1(), user.getData().getPerks().getActivePerk1().toType()
//				.newPerkTypePerk(user, PerkNumber.ACTIVE_1).getItem().getItem(user));
//		v.setItem(user.getData().getPerks().getSlotActivePerk2(), user.getData().getPerks().getActivePerk2().toType()
//				.newPerkTypePerk(user, PerkNumber.ACTIVE_2).getItem().getItem(user));
//		v.setItem(user.getData().getPerks().getSlotPassivePerk(), user.getData().getPerks().getPassivePerk().toType()
//				.newPerkTypePerk(user, PerkNumber.PASSIVE).getItem().getItem(user));
		for (int i = 0; i < woolcount; i++) {
			p.getInventory().addItem(
					new ItemBuilder(Material.WOOL).setDurability(user.getTeam().getType().getWoolColor()).build());
		}
		p.getHandle().updateInventory(p.getHandle().activeContainer);
	}

	private void setPlayerItem(InventoryView v, int slot, ItemStack item) {
		if (slot == 100)
			v.setCursor(item);
		else
			v.setItem(slot, item);
	}

	public void setSpectator(User user) {
		Player p = user.getBukkitEntity();
		Main.getInstance().getTeamManager().setTeam(user, Main.getInstance().getTeamManager().getSpectator());
		Scoreboard sb = new Scoreboard();
		p.setScoreboard(sb.getScoreboard());
		Main.initScoreboard(sb, user);
		Main.getInstance().getUserWrapper().getUsers().forEach(u -> {
			Scoreboard s = new Scoreboard(u);
			s.getTeam(user.getTeam().getType().getScoreboardTag()).addPlayer(user.getPlayerName());
			if (u.getTeam().getType() != TeamType.SPECTATOR) {
				u.getBukkitEntity().hidePlayer(p);
			} else {
				p.showPlayer(u.getBukkitEntity());
			}
			if (u != user) {
				sb.getTeam(u.getTeam().getType().getScoreboardTag()).addPlayer(u.getPlayerName());
			}
		});
		loadScoreboardObjective(user);
		reloadTab(user);
		p.spigot().setCollidesWithEntities(false);
		p.setAllowFlight(true);
	}

	public void reloadScoreboardLifes(User user) {
		Scoreboard sb = new Scoreboard(user);
		for (Team team : Main.getInstance().getTeamManager().getTeams()) {
			reloadScoreboardLifes(sb, team);
		}
	}

	public void reloadScoreboardLifes(Scoreboard sb, Team team) {
		String llifes = Integer.toString(team.getLifes());
		if (llifes.length() > 3) {
			llifes = llifes.substring(0, 3);
		}
		sb.getTeam(team.getType().getIngameScoreboardTag())
				.setPrefix(ChatColor.translateAlternateColorCodes('&', "&6" + Characters.SHIFT_SHIFT_RIGHT + " &4"
						+ Characters.HEART + "&r" + llifes + "&4" + Characters.HEART + " "));
	}

	public void reloadTab(User user) {
		Header header = new Header(Main.getInstance().getConfig("config").getString(Config.TAB_HEADER));
		Footer footer = new Footer(Main.getInstance().getConfig("config").getString(Config.TAB_FOOTER));
		header.setMessage(header.getMessage().replace("%map%",
				Main.getInstance().getMap() == null ? "Unknown Map" : Main.getInstance().getMap().getName()));
		footer.setMessage(footer.getMessage().replace("%map%",
				Main.getInstance().getMap() == null ? "Unknown Map" : Main.getInstance().getMap().getName()));
		header.setMessage(header.getMessage().replace("%name%", Main.getInstance().name));
		footer.setMessage(footer.getMessage().replace("%name%", Main.getInstance().name));
		header.setMessage(header.getMessage().replace("%prefix%", "&8" + Characters.SHIFT_SHIFT_RIGHT + " &6"
				+ Main.getInstance().tabprefix + " &8" + Characters.SHIFT_SHIFT_LEFT));
		footer.setMessage(footer.getMessage().replace("%prefix%", "&8" + Characters.SHIFT_SHIFT_RIGHT + " &6"
				+ Main.getInstance().tabprefix + " &8" + Characters.SHIFT_SHIFT_LEFT));
		header.setMessage(header.getMessage().replace("%server%", Bukkit.getServerName()));
		footer.setMessage(footer.getMessage().replace("%server%", Bukkit.getServerName()));
		header.setMessage(ChatColor.translateAlternateColorCodes('&', header.getMessage()).replace("\\n", "\n"));
		footer.setMessage(ChatColor.translateAlternateColorCodes('&', footer.getMessage()).replace("\\n", "\n"));
		TabManager.setHeaderFooter(user, header, footer);
	}

	public void attack(User user, User target) {
		if ((!isGlobalSpawnProtection && !target.hasSpawnProtection() && target.getTeam() != user.getTeam())
				|| user.isTrollMode()) {
			target.setLastHit(user);
			target.setTicksAfterLastHit(0);
		}
	}

	public static int getBlockDamage(Block block) {
		if (block.getMetadata("arrowDamage").size() == 0)
			return 0;
		return block.getMetadata("arrowDamage").get(0).asInt();
	}

	public static void resetBlockDamage(Block block) {
		block.removeMetadata("arrowDamage", Main.getInstance());
	}

	public static void playSoundNotEnoughWool(User user) {
		user.getBukkitEntity().playSound(user.getBukkitEntity().getLocation(), Sound.VILLAGER_NO, 1, 1);
	}

	@SuppressWarnings("deprecation")
	public static void setBlockDamage(Block block, int damage) {
		EventDamageBlock damageBlock = new EventDamageBlock(block, getBlockDamage(block), damage);
		if (damageBlock.isCancelled()) {
			return;
		}
		if (damage >= MAX_BLOCK_ARROW_HITS) {
			EventDestroyBlock destroyBlock = new EventDestroyBlock(block);
			if (!destroyBlock.isCancelled()) {
				Ingame ingame = Main.getInstance().getIngame();
				if (ingame.placedBlocks.contains(block)) {
					ingame.placedBlocks.remove(block);
				} else {
					ingame.breakedWool.put(block, block.getData());
				}
				block.setType(Material.AIR);
				resetBlockDamage(block);
				return;
			}
		}
		block.setMetadata("arrowDamage", new FixedMetadataValue(Main.getInstance(), damage));
	}
}