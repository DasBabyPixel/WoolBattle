package eu.darkcube.minigame.woolbattle.perk;

import java.util.Collection;

import org.bukkit.inventory.ItemStack;

import eu.darkcube.minigame.woolbattle.user.User;
import eu.darkcube.minigame.woolbattle.util.Arrays;
import eu.darkcube.minigame.woolbattle.util.Item;
import eu.darkcube.minigame.woolbattle.util.observable.ObservableInteger;

public interface Perk {

	int getMaxCooldown();

	boolean hasCooldown();

	Item getCooldownItem();

	Item getItem();

	void setItem();

	ItemStack calculateItem();

	PerkName getPerkName();

	String getDisplayName();

	ObservableInteger getSlotLink();

	void setSlot(int slot);

	void setSlotSilent(int slot);

	int getSlot();

	ObservableInteger getCooldownLink();

	void setCooldown(int cooldown);

	int getCooldown();

	User getOwner();

	boolean isHardCooldown();

	void setHardCooldown(boolean hardCooldown);

	PerkNumber getPerkNumber();

	public static Collection<PerkType> getAllPerks() {
		return Arrays.asList(PerkType.values());
	}
}
