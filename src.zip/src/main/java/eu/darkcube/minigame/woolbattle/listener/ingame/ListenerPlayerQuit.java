package eu.darkcube.minigame.woolbattle.listener.ingame;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerQuitEvent;

import eu.darkcube.minigame.woolbattle.Main;
import eu.darkcube.minigame.woolbattle.listener.Listener;
import eu.darkcube.minigame.woolbattle.team.TeamType;
import eu.darkcube.minigame.woolbattle.translation.Message;
import eu.darkcube.minigame.woolbattle.user.User;

public class ListenerPlayerQuit extends Listener<PlayerQuitEvent> {
	@Override
	@EventHandler
	public void handle(PlayerQuitEvent e) {
		e.setQuitMessage(null);
		Main main = Main.getInstance();
		Player p = e.getPlayer();
		User user = main.getUserWrapper().getUser(p.getUniqueId());
		if (user.getTeam().getType() == TeamType.SPECTATOR) {
			return;
		}
		main.getIngame().kill(user, true);
		main.getUserWrapper().getUsers().forEach(
				u -> u.getBukkitEntity().sendMessage(Message.PLAYER_LEFT.getMessage(u, user.getTeamPlayerName())));
		main.sendConsole(
				Message.PLAYER_LEFT.getMessage(Main.getInstance().getServerLanguage(), user.getTeamPlayerName()));
	}
}