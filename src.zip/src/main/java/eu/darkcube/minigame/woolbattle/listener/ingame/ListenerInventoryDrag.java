package eu.darkcube.minigame.woolbattle.listener.ingame;

import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryDragEvent;

import eu.darkcube.minigame.woolbattle.listener.Listener;

public class ListenerInventoryDrag extends Listener<InventoryDragEvent> {
	@Override
	@EventHandler
	public void handle(InventoryDragEvent e) {
		if(e.getOldCursor() != null && e.getOldCursor().getType() != Material.WOOL) {
			e.setCancelled(true);
		}
	}
}