package eu.darkcube.minigame.woolbattle.util.observable;

public abstract class SimpleObservableLong extends SimpleObservableObject<Long> implements ObservableLong {

}
